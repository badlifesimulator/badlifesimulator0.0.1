Images, fonts and sounds go in the assets folder; js in js and css in css. html remains in the root folder.

if you'd like to play this game offline, run the index.html file in a web browser like chrome. if you run it in internet explorer you will be arrested.