//Author(s): Ethan Scott//

revent = localStorage.getItem("revent"); //gets revent from local storage//

if (revent === "lotteryLowRiskWon")  { //lottery low risk won//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "You won! $400 has been deposited into your account.";
	Joy + 10;
	document.getElementById("eventOutcome").innerHTML = "Joy + 10";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryLowRiskLost")  { //lottery low risk lost//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "Shucks, you lost the lottery. $50 has been deducted from your account.";
	document.getElementById("eventOutcome").innerHTML = "";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryLowRiskFlatBroke") { //lottery low risk flat broke (i.e. can't afford)//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "You just remembered you can't afford to play the lottery.";
	document.getElementById("eventOutcome").innerHTML = "";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryMediumRiskWon")  { //lottery medium risk won//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "You won!! $10,000 has been deposited into your account.";
	Joy + 20;
	document.getElementById("eventOutcome").innerHTML = "Joy + 20";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryMediumRiskLost")  { //lottery medium risk lost//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "Shucks, you lost the lottery. $50 has been deducted from your account.";
	document.getElementById("eventOutcome").innerHTML = "";
	console.log("event display completed");
	
		button1.addEventListener('click', () => { 
		window.location.href = "./home.html";
})} else if (revent === "lotteryMediumRiskFlatBroke") { //lottery medium risk flat broke (i.e. can't afford)//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "You just remembered you can't afford to play the lottery.";
	document.getElementById("eventOutcome").innerHTML = "";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryHighRiskWon")  { //lottery high risk won//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "Oh my god! You won!!! $5,000,000 has been deposited into your account.";
	Joy + 70;
	document.getElementById("eventOutcome").innerHTML = "Joy + 70";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryHighRiskLost")  { //lottery high risk lost//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "Shucks, you lost the lottery. $50 has been deducted from your account.";
	document.getElementById("eventOutcome").innerHTML = "";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})} else if (revent === "lotteryHighRiskFlatBroke") { //lottery high risk flat broke (i.e. can't afford)//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Lottery";
	document.getElementById("eventText").innerHTML = "You just remembered you can't afford to play the lottery.";
	document.getElementById("eventOutcome").innerHTML = "";
	console.log("event display completed");
	
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";
})}

if (revent === "job-appr-int-designer-accepted")  { //accepted as apprentice interior designer//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Interior Designer";
	document.getElementById("eventText").innerHTML = "You were accepted for the position of Apprentice Interior Designer!";
	Salary = 45000;
	Joy += 10;
	hasJob = true;
	Job = "appr-int-designer";
	Logs = "I got the position of Apprentice Interior Designer! My salary is now $45,000 /yr!";
	document.getElementById("eventOutcome").innerHTML = "Salary = $45,000 /yr <br> Joy + 10";
	console.log("event display completed");
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";})
} else if (revent === "job-appr-int-designer-rejected") { //rejected as apprentice interior designer//
	console.log("revent: "+ revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Interior Designer";
	document.getElementById("eventText").innerHTML = "Unfortunately, you were rejected for the position of Apprentice Interior Designer. You are unqualified.";
	hasJob = false;
	Job = "";
	console.log(Joy);
	Joy -= 5;
	console.log(Joy);
	document.getElementById("eventOutcome").innerHTML = "Joy - 5";
	Logs = "I did not become an apprentice interior designer. Instead, I became unemployed.";
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";})
} else if (revent === "job-int-designer-accepted")  { //accepted as interior designer//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Interior Designer";
	document.getElementById("eventText").innerHTML = "You were accepted for the position of Interior Designer!";
	Salary = 60000;
	Joy += 10;
	hasJob = true;
	Job = "int-designer";
	Logs = "I got the position of Interior Designer! My salary is now $60,000 /yr!";
	document.getElementById("eventOutcome").innerHTML = "Salary = $60,000 /yr <br>";
	console.log("event display completed");
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";})
} else if (revent === "job-int-designer-rejected") { //rejected as interior designer//
	console.log("revent: "+ revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Interior Designer";
	document.getElementById("eventText").innerHTML = "Unfortunately, you were rejected for the position of Interior Designer. You are unqualified.";
	hasJob = false;
	Job = "";
	Joy -= 5;
	document.getElementById("eventOutcome").innerHTML = "Joy - 5";
	Logs = "I did not become an interior designer. Instead, I became dissapointed.";
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";})
} else if (revent === "job-sr-int-designer-accepted")  { //accepted as senior interior designer//
	console.log("revent: " + revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Interior Designer";
	document.getElementById("eventText").innerHTML = "You were accepted for the position of Senior Interior Designer!";
	Salary = 90000;
	Joy += 15;
	hasJob = true;
	Job = "sr-int-designer";
	Logs = "I got the position of Senior Interior Designer! My salary is now $90,000 /yr!";
	document.getElementById("eventOutcome").innerHTML = "Salary = $90,000 /yr";
	console.log("event display completed");
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";})
} else if (revent === "job-sr-int-designer-rejected") { //rejected as senior interior designer//
	console.log("revent: "+ revent)
	revent = ""
	document.getElementById("eventTitle").innerHTML = "Interior Designer";
	document.getElementById("eventText").innerHTML = "Unfortunately, you were rejected for the position of Senior Interior Designer. You are unqualified.";
	hasJob = false;
	Job = "";
	Joy -= 5;
	document.getElementById("eventOutcome").innerHTML = "Joy - 5";
	Logs = "I did not become a senior interior designer. Instead, I became broke.";
		button1.addEventListener('click', () => {
		window.location.href = "./home.html";})
}

localStorage.setItem("Job", Job);
localStorage.setItem("hasJob", hasJob);
localStorage.setItem("Salary", Salary);
localStorage.setItem("Logs", Logs);
localStorage.setItem("Joy", Joy);
localStorage.setItem("revent", "");

console.log("successfully run event.js")