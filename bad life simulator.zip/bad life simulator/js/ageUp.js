//Author(s): Ethan Scott//

function getRandomIntInclusive(min, max) { //function for the random age event//
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

document.getElementById("plus").addEventListener("click", function() {
	Age ++;
	Money += (Salary / 100) * 30 //adds 30% of salary to money//
	rnumber = getRandomIntInclusive(1, 2); //gets a random number between x and y//
	console.log("rnumber === "+rnumber);
	localStorage.setItem("Age", Age);
	localStorage.setItem("Money", Money);
		if (rnumber === 1) {
			window.location.reload(); //reloads the page//
		} else if (rnumber === 2) {
			rfunction = "ageUpEvent"
			rnumber = getRandomIntInclusive(1, 10); //gets another random number between x and y//
			localStorage.setItem("rfunction", rfunction);
			localStorage.setItem("rnumber", rnumber);
			window.location.href = "./event.html";}
		}
);