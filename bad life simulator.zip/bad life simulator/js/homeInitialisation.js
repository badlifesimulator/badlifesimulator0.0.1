//Author(s): Ethan Scott//

//to add a new variable, duplicate each of these functions and change the variable name. to change the default value, just change the number it defaults to below (do not change Age)//

//initialises variables for a new game//
    let Age = 0;
	let Joy = 50;
	let Health = 50;
	let Intellect = 50;
	let Looks = 50;
	let Karma = 50;
	let Money = 0;
	let rnumber = 0;
	let rfunction = "";
	let revent = "";
	let Logs = "";
    localStorage.setItem("Age", Age);
    localStorage.setItem("Joy", Joy);
    localStorage.setItem("Health", Health);
    localStorage.setItem("Intellect", Intellect);
    localStorage.setItem("Looks", Looks);
    localStorage.setItem("Karma", Karma);
    localStorage.setItem("Money", Money);
	localStorage.setItem("rnumber", rnumber);
	localStorage.setItem("rfunction", rfunction);
	localStorage.setItem("revent", revent);
    localStorage.setItem("Logs", Logs);
	
//obscure variables//
	let redirect = ""
	localStorage.setItem("redirect", redirect);

//career variables//
	let hasJob = false;
	let Job = "";
	let Salary = 0;
	let Degree = [];
	let workExperience = [];
	localStorage.setItem("hasJob", hasJob);
	localStorage.setItem("Job", Job);
	localStorage.setItem("Salary", Salary);
	localStorage.setItem("Degree", Degree);
	localStorage.setItem("workExperience", workExperience);
	console.log("new variables set.")
	console.log("new game successfuly set up.")